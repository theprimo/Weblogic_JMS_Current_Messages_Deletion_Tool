package com.acci.lgi.sso;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;

import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

import com.codeborne.selenide.SelenideElement;

public class DeleteJMSQueueMsgs extends OpenConsoleNdeleteMessages {

	//goto JMS module
	public static void deleteJMSQueuesMessages(){
		try{
			writeString="[Info]: Deleting JMS queue messages takes place.";
			System.out.println(writeString);
			bw.write(writeString+"\n"); //write to log file
			boolean dummyFlag=true;
			int modulesCounter,queuesCounter,counter;
			String strCurJMSQueueName=null,strCurJMSModuleName=null;
			for(modulesCounter=1;modulesCounter<=noOfJMSModules;modulesCounter++){
				String homeURL=weblogicconsoleproperties.getProperty("HOMEURL");
				String arr[] = homeURL.split("/console");
				String jmsModulesURL=arr[0]+"/console/console.portal?_nfpb=true&_pageLabel=JmsModulesTablePage"; //build JMS modules page url
				open(jmsModulesURL);//Goto JMS Modules page
				Thread.sleep(5000);
				$(By.id("genericTableForm")).shouldBe(visible);//let the page gets loaded properly
				//open JMS module, go to JMS module queues page - JMSMODULENAME1
				strCurJMSModuleName=weblogicconsoleproperties.getProperty("JMSMODULENAME"+Integer.toString(modulesCounter));
				$(By.partialLinkText(strCurJMSModuleName)).click();
				Thread.sleep(5000);
				$(By.id("JMSSystemModulesTabsBook")).shouldBe(visible);//let the page gets loaded properly
				//get current module no.of jms queues - NOOFMODULE1QUEUES
				noOfJMSQueues=Integer.parseInt(weblogicconsoleproperties.getProperty("NOOFMODULE"+Integer.toString(modulesCounter)+"QUEUES"));
				//go through JMS Queues of current JMS module one by one
				for(queuesCounter=1;queuesCounter<=noOfJMSQueues;queuesCounter++){
					int noOfMsgsToDisplay,noOfMsgsDelindex,noOfJMSServerQueues;
					//open JMS Queue - MODULE1JMSQUEUENAME1
					strCurJMSQueueName=weblogicconsoleproperties.getProperty("MODULE"+Integer.toString(modulesCounter)+"JMSQUEUENAME"+Integer.toString(queuesCounter));
					$(By.partialLinkText(strCurJMSQueueName)).click();
					Thread.sleep(5000); 
					$(By.id("JmsUniformDistributedQueuesBook")).shouldBe(visible);
					if($(By.partialLinkText("Monitoring")).exists()&&$(By.partialLinkText("Monitoring")).isEnabled()){
						$(By.partialLinkText("Monitoring")).click(); //goto monitoring tab
						Thread.sleep(5000);
						$(By.id("genericTableFormtable")).shouldBe(visible);						
					}
					//get all server queues check box ids
					List<SelenideElement> list = $(By.id("genericTableFormtable")).findAll(By.id("JMSUniformDistributedQueueMonitorPortletchosenContents"));
					
					noOfJMSServerQueues = list.size();
					//go through all server queues one by one & delete messages
					for(counter=1;counter<=noOfJMSServerQueues;counter++){
						int msgsDeleted=0;
						String strJMSServerMsgsDeletionQueueName=null;
						list = $(By.id("genericTableFormtable")).findAll(By.id("JMSUniformDistributedQueueMonitorPortletchosenContents"));
						strJMSServerMsgsDeletionQueueName = $(By.id("Name"+Integer.toString(counter))).getText().trim(); //get JMSserverQueue name
						writeString="We are at : "+strCurJMSModuleName+"->"+strCurJMSQueueName+"->"+strJMSServerMsgsDeletionQueueName;
						System.out.println(writeString); //print just where we're in
						bw.write(writeString+"\n"); //write to log
						list.get(counter-1).setSelected(true);//access queue check box list element by index
						Thread.sleep(1000); 
						List<SelenideElement> showMsgBtnList = $(By.className("tablecontrols")).findAll(By.tagName("button"));
						showMsgBtnList.get(0).click();//click on show messages
						Thread.sleep(5000);
						$(By.id("jMSMessageTableFormtable")).shouldBe(visible);	
						//one time preference table customization
						if(dummyFlag==true){
							$(By.partialLinkText("Customize this table")).click();
							Thread.sleep(5000); //10-0,25-1,100-2,1000-3,5000-4
							$(By.id("JmsJMSMessageTablePortlettablePreferences.rowsPerPage")).shouldBe(visible);
							//set value for no.of Messages to delete each time
							noOfMsgsToDisplay=Integer.parseInt(weblogicconsoleproperties.getProperty("NOOFMSGSTODELETEEACHTIME"));
							if(noOfMsgsToDisplay == 10){
								noOfMsgsDelindex=0;
							}else if(noOfMsgsToDisplay == 25){
								noOfMsgsDelindex=1;
							}else if(noOfMsgsToDisplay == 100){
								noOfMsgsDelindex=2;
							}else if(noOfMsgsToDisplay == 1000){
								noOfMsgsDelindex=3;
							}else{
								noOfMsgsDelindex=2;
							}
							//default value is to delete 100 msgs each time
							$(By.id("JmsJMSMessageTablePortlettablePreferences.rowsPerPage")).selectOption(noOfMsgsDelindex);	
							//formButton , JMSUniformDistributedQueueMonitorPortlet
							List<SelenideElement> btnsList = $(By.className("dialog")).findAll(By.className("formButton"));
							btnsList.get(0).click();//apply preferences
							Thread.sleep(5000);
							$(By.partialLinkText("Customize this table")).shouldBe(visible);
							dummyFlag=false;
						}

						msgsDeleted=openQueueNDeleteMsgs(strCurJMSQueueName);
						try {
							writeString="No.of msgs deleted on "+strJMSServerMsgsDeletionQueueName+" : "+msgsDeleted;
							System.out.println(writeString);
							bw.write(writeString+"\n");
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}//current jms queue msgs deleted, again goto jms queues page and go further
					$(By.partialLinkText(strCurJMSModuleName)).click();
					Thread.sleep(5000);
					$(By.id("JMSSystemModulesTabsBook")).shouldBe(visible);
				}				
			}	
			//write status
			writeString="[Info]: JMS messages deleted successfully for respective queues.";
			System.out.println(writeString);
			bw.write(writeString+"\n"); //write to log
			//logout from the console
			$(By.className("tbframe")).find(By.partialLinkText("Log Out")).click();
			Thread.sleep(5000);
			writeString="[Info]: Logged out from console successfully.";
			System.out.println(writeString);
			bw.write(writeString+"\n"); //write to log
		}catch(NoSuchElementException nsee){
			try {
				bw.write(nsee.getMessage()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		catch(Exception e){
			try {
				System.out.println(e.getMessage());
				bw.write(e.getMessage()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

	}

	//delete respective queue messages
	@SuppressWarnings("finally")
	private static int openQueueNDeleteMsgs(String strCurJMSQueueName) {
		String temp,strNoOfMsgsDeleted;
		int noOfMsgsDeleted=0,noOfMsgsLeftInQueue=0;
		try{
			while(true){
				//track deleted messages count
				if($(By.id("asyncmessages")).find(By.className("message")).exists()){
					strNoOfMsgsDeleted = $(By.id("asyncmessages")).find(By.className("message")).getText();
					str = new StringTokenizer(strNoOfMsgsDeleted," ");
					temp=str.nextToken().trim();
					if(temp.equals("1,000")){
						noOfMsgsDeleted +=1000;
					}else{
						noOfMsgsDeleted += Integer.parseInt(temp); 
					}
				}
				//if(noOfMsgsDeleted>=1000) break;
				$(By.id("jMSMessageTableFormtable")).shouldBe(visible); 
				$(By.id("JmsJMSMessageTablePortletselector")).shouldBe(visible); 
				//get messages count
				temp = $(By.id("jMSMessageTableForm")).find(By.className("tablenavigation")).getText().trim();
				str = new StringTokenizer(temp, " ");
				str.nextToken();
				str.nextToken().trim();
				str.nextToken(); str.nextToken(); str.nextToken();

				noOfMsgsLeftInQueue = Integer.parseInt(str.nextToken().trim()); //get left msgs count in queue
				if(noOfMsgsDeleted>=maxNoOfMsgsToDelete || noOfMsgsLeftInQueue<=10 ){ 
					//once we're done here, goto JMS server message queues page
					$(By.partialLinkText(strCurJMSQueueName)).click();
					Thread.sleep(5000);
					$(By.id("JmsUniformDistributedQueuesBook")).shouldBe(visible);
					if($(By.partialLinkText("Monitoring")).exists()&&$(By.partialLinkText("Monitoring")).isEnabled()){
						$(By.partialLinkText("Monitoring")).click(); //goto monitoring tab
						Thread.sleep(5000);
						$(By.id("genericTableFormtable")).shouldBe(visible);
					}
					break; 
				}
				//select all msgs check box to delete all msgs
				$(By.id("jMSMessageTableFormtable")).find(By.name("all")).setSelected(true);
				$(By.id("jMSMessageTableForm")).find(By.name("Delete")).click();
				$(By.partialLinkText("Delete")).click(); //delete messages
				Thread.sleep(5000);
				$(By.id("JmsDeleteJMSMessagePortlet")).find(By.name("Yes")).shouldBe(visible);
				$(By.id("JmsDeleteJMSMessagePortlet")).find(By.name("Yes")).click(); //give confirmation
				Thread.sleep(10000); //deletion confirmation
			}
		}catch(NoSuchElementException nsee){
			try {
				bw.write(nsee.getMessage()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		catch(Exception e){
			try {
				System.out.println(e.getMessage());
				bw.write(e.getMessage()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		finally{
			return noOfMsgsDeleted;
		}

	}

}
