package com.acci.lgi.sso;

import java.io.BufferedWriter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.StringTokenizer;

import org.openqa.selenium.By;
import static com.codeborne.selenide.WebDriverRunner.CHROME;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;

import com.acci.lgi.sso.DeleteJMSQueueMsgs;

public class OpenConsoleNdeleteMessages {
	static String logFilePath;
	static File logFile;
	static FileWriter fw;
	static BufferedWriter bw;
	static Properties weblogicconsoleproperties;
	static int noOfJMSModules;
	static int noOfJMSQueues;
	static int noOfSheets;
	static int noOfServerTypes;
	static int maxNoOfMsgsToDelete;
	static String writeString;
	static StringTokenizer str;

	//Initialize variables
	private static void initialize(){
		logFilePath=null;
		logFile=null;
		fw=null;
		bw=null;
		weblogicconsoleproperties=null;
		writeString=null;
		
				
		//create log file
		try {
			
			logFilePath = System.getProperty("user.dir")+"\\"+ "DeleteJMSQueueMessagesLog.log";
			//logFilePath = "C:\\New folder\\Daily_Healh_Check\\DeleteJMSQueueMessages\\"+ "DeleteJMSQueueMessagesLog.log";
			logFile = new File(logFilePath);
			fw = new FileWriter(logFile.getAbsoluteFile());
			bw = new BufferedWriter(fw);
		} catch (IOException e) {
			try {
				bw.write("[Error]: Unable to connect to the log file!!"+"\n");
				e.printStackTrace();
				bw.write(e.toString()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		//set default session & test timeout
		System.setProperty("selenide.collectionsTimeout", "60000");
		System.setProperty("selenide.timeout", "60000");
		//System.out.println(com.codeborne.selenide.Configuration.timeout);

		//set binary chromedriver path	
		try {
			File file = new File(System.getProperty("user.dir")+"\\"+ "chromedriver.exe");
			//File file = new File("C:\\New folder\\Daily_Healh_Check\\DeleteJMSQueueMessages\\"+ "chromedriver.exe");
			System.setProperty("webdriver.chrome.driver",file.getAbsolutePath());
		} catch (Exception e) {
			try {
				writeString="[Error]: Chromium binary chromedriver.exe file was not found, please check!!";
				System.out.println(writeString);
				bw.write(writeString+"\n");
				e.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		//set default browser to chrome
		System.setProperty("browser", CHROME);
		System.setProperty("selenide.browser",System.getProperty("browser", CHROME));

		//load properties from external config.properties file		
		weblogicconsoleproperties = new Properties();
		try {
			//weblogicconsoleproperties.load(new FileInputStream("C:\\New folder\\Daily_Healh_Check\\DeleteJMSQueueMessages\\"+"config.properties"));
			weblogicconsoleproperties.load(new FileInputStream(System.getProperty("user.dir")+"\\"+"config.properties"));
		
		} catch (FileNotFoundException e) {
			try {
				writeString="[Error]: config.properties file was not found, please check!!";
				System.out.println(writeString);
				bw.write(writeString+"\n");
				e.printStackTrace();
				bw.write(e.toString()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String temp;
		noOfJMSModules=Integer.parseInt((weblogicconsoleproperties.getProperty("NOOFJMSMODULES").trim()));
		temp=weblogicconsoleproperties.getProperty("MAXNOFMSGSTODELETE").trim();
		if(temp.equalsIgnoreCase("ALL")){
			maxNoOfMsgsToDelete = 2147483647; //set to max integer value of Java
		}else{
			maxNoOfMsgsToDelete=Integer.parseInt(temp);
		}
		
		
	}

	//Login to the console
	public static boolean loginToConsole(){
		boolean isLoginSuccess=true;
		try{
			String strCurPageURL;
			open(weblogicconsoleproperties.getProperty("HOMEURL"));//Goto console login page
			com.codeborne.selenide.WebDriverRunner.clearBrowserCache();//clear cache
			Thread.sleep(5000);
			//Check if session is already logged in
			strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
			if(strCurPageURL.endsWith("_pageLabel=HomePage1")){
				//fine, already some one logged in
				if($(By.id("toolbarSearchInput")).exists()) { $(By.id("toolbarSearchInput")).shouldBe(visible); }
				Thread.sleep(2000);
			}else if(strCurPageURL.endsWith("LoginForm.jsp")){  
				$(By.name("j_username")).shouldBe(visible);
				Thread.sleep(1000);
				$(By.name("j_username")).setValue(weblogicconsoleproperties.getProperty("USERNAME"));
				$(By.name("j_password")).setValue(weblogicconsoleproperties.getProperty("PASSWORD"));
				$(By.className("formButton")).click();
				Thread.sleep(5000);
				//check login is successful or not?
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				if(strCurPageURL.endsWith("_pageLabel=HomePage1")){
					if($(By.id("toolbarSearchInput")).exists()) { $(By.id("toolbarSearchInput")).shouldBe(visible); }
					if($(By.className("wlsc-book-content")).exists()) { $(By.className("wlsc-book-content")).shouldBe(visible); }
				}else{
					//login failed - log the trace
					isLoginSuccess=false;
				}
			}			
		}
		catch(InterruptedException ie){
			try {
				bw.write(ie.getMessage()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}catch(Exception e){
			try {
				bw.write(e.getMessage()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		

		return isLoginSuccess;
	}

	//Start execution
	public static void main(String[] args) {
		try{
			initialize();
			if(loginToConsole()){ //If login success
				writeString="[Info]: Logged into console successfully.";
				System.out.println(writeString);
				bw.write(writeString+"\n"); //write to log
				DeleteJMSQueueMsgs.deleteJMSQueuesMessages();
				
			}else{
				writeString="[Error]: Unable to login to the weblogic console, please check creds & application status immediately!!";
				System.out.println(writeString);
				bw.write(writeString+"\n"); //write to log
			}
		}catch(Exception e){
			try {
				System.out.println("[Error]: "+e.toString());
				bw.write("[Error]: "+e.toString()+"\n");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		finally{
			try {
				//close file streams
				if(null!=bw){bw.close();}
				if(null!=fw){fw.close();}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}
}
