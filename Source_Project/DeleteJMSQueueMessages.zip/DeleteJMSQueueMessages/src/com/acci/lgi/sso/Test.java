package com.acci.lgi.sso;

public class Test {

	public static void main(String[] args) {
		String str="http://172.31.130.119:9001/console";
		String arr[] = str.split("/console");
		String jmsModulesURL=arr[0]+"/console/console.portal?_nfpb=true&_pageLabel=JmsModulesTablePage";
		System.out.println(jmsModulesURL);
		
		String temp ="Showing 1 to 10 of 1569945   PreviousNext";
		String[] parts = temp.split("[ ]{2,}");
		//System.out.println(parts);
		for(String s:parts){
			System.out.println(s);
		}
	}

}
